const ServiceData = [
  {
    id: 1,
    img_src:
      "https://d3t5ai5vcxyqte.cloudfront.net/media/jtklaazjieqhljbboiyao.svg",
    title: "Лечение корневых каналов",
    description: "Давайте спасем зуб",
  },
  {
    id: 2,
    img_src: "https://d3t5ai5vcxyqte.cloudfront.net/media/xerhpggjxuxmfpsu.svg",
    title: "Отбеливание зубов",
    description: "Ты смотришь на более белые зубы?",
  },
  {
    id: 3,
    img_src:
      "https://d3t5ai5vcxyqte.cloudfront.net/media/xckdqmsbqpdhzlhvwood.svg",
    title: "Зубные имплантаты",
    description: "Мы сделаем так, чтобы ваши имплантаты прослужат вам всю жизнь.",
  },
  {
    id: 4,
    img_src: "https://d3t5ai5vcxyqte.cloudfront.net/media/ztyabpe.svg",
    title: "Зубные протезы",
    description: "Мы определим, какой тип зубного протеза подходит именно вам.",
  },
  {
    id: 5,
    img_src:
      "https://d3t5ai5vcxyqte.cloudfront.net/media/pegjpxeakmijzlnklbubfsfun.svg",
    title: "Зубные пломбы",
    description: "Установим лучшие пломбы, которые хорошо сочетаются друг с другом..",
  },
  {
    id: 6,
    img_src: "https://d3t5ai5vcxyqte.cloudfront.net/media/znrdvnh.svg",
    title: "Ортодонтическое лечение/брекеты",
    description: "Никогда не стесняйся улыбаться",
  },
  {
    id: 7,
    img_src:
      "	https://d3t5ai5vcxyqte.cloudfront.net/media/trteeoeviitzkuduaj.svg",
    title: "Косметическая стоматология",
    description: "Пришло время показать эту улыбку",
  },
  {
    id: 8,
    img_src:
      "	https://d3t5ai5vcxyqte.cloudfront.net/media/rkkaxifntuslufcqwxelgzu.svg",
    title: "Детская стоматология",
    description: "Мы сделаем все для здоровья зубов вашего ребенка",
  },
];

export default ServiceData;
